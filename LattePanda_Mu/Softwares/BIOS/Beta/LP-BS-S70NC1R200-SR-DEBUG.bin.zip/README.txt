LP-BS-S70NC1R200-SR-DEBUG

Enable intel DCI Debug interface and EFI log

EFI log output at SOC_UART0, baud rate 115200

With log output enabled, bootup is very very SLOW, which is normal.
