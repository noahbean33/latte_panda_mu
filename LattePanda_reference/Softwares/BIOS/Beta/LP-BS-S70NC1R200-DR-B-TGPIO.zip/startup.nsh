@echo -off 
for %a run (0 15 1) 
  if exist fs%a:\LP-BS-S70NC1R200-DR-B-TGPIO then  
     fs%a:  
     cd LP-BS-S70NC1R200-DR-B-TGPIO 
     cls  
     BIOS.nsh 
  endif  
endfor  
